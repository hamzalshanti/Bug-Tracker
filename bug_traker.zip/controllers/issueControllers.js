const Issue = require('../models/issueModel');
const Project = require('../models/projectModel');
const { projectValidation } = require('../utils/validation');

const getAllIssues = async (req, res) => {
  try {
    const issues = await Issue.find({});
    if (issues.length === 0)
      return res.status(200).json({
        issues: [],
      });
    return res.status(200).json(issues);
  } catch (err) {
    next(err);
  }
};

const getIssue = async (req, res) => {
  try {
    const issue = await Issue.findById(req.params.id);
    return res.status(200).json(issue);
  } catch (err) {
    next(err);
  }
};

const createIssue = async (req, res) => {
  try {
    const { errors } = validationResult(req);
    if (errors.length > 0)
      return res.status(422).json({
        errors: errors,
      });

    // Get project Slug.
    const { slug } = await Project.findById(req.body.project_id);
    const number = await Issue.findById(req.body.project_id).countDocuments();
    const issue = await Issue.create({
      issueNumber: `${slug}-${number + 1}`,
      title: req.body.title,
      description: req.body.description,
      status: req.body.status,
      Project_ID: req.body.project_id,
    });
    return res.status(201).json({
      message: 'created successfully',
      issue: issue,
    });
  } catch (err) {
    next(err);
  }
};

//const updateIssueStatus = (req, res) => {};

const getAllComments = async (req, res) => {};

const getComment = async (req, res) => {};

const createComment = async (req, res) => {};

module.exports = {
  getAllIssues,
  getIssue,
  createIssue,
  //updateIssueStatus,
  getAllComments,
  getComment,
  createComment,
};
